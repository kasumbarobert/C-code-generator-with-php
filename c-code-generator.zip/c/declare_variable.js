function $(id)
	{
		return document.getElementById(id);
	}//function to replace the long document.getElementById with $;

