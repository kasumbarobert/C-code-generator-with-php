#include<stdio.h>
 #include<math.h>

int main(void) {
int age1=10;

int age2=20;

int age3=30;

int sum=0;

int average;

sum=age1+age2+age3;
average=sum/3;
printf("the average is %d", average);}
printf("stop being lazy");
