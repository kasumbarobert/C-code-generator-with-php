#include<stdio.h>
 #include<math.h>

int main(void) {
printf("hello world!");
int a=2;

int a=2;

int b=2;
if((b%2)!=0){
printf("%d is a prime number", b);}else {
printf("%d is not a prime number", b); 
}while(b=<1000){
printf("%d", b);
b++;}
