#include<stdio.h>
 #include<math.h>

int main(void) {
float wage;

int hourly_rate;

printf("Testing the system");
