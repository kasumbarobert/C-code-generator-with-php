#include<stdio.h>
 #include<math.h>

int main(void) {
int grade=0;

int a=0;

int b=0;

int c=0;

int d=0;

int e=0;

int f=0;

printf("enter the grade");
printf("enter the EOF character to end input");
