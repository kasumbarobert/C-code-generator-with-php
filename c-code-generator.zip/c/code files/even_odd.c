/*Test for even numbers*/
#include <stdio.h>
#include <math.h>


int main(void) {
int n;

int n;

printf("Enter an integer no ");
scanf("%d",&n);if(n%2 == 0){
printf("%d is an even number \n", n); 
}if(n%2!=0){
printf("%n is an odd number");
printf("\n"); 
}}
