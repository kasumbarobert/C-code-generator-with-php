#include<stdio.h>
 #include<math.h>

int main(void) {
int num1;

int num2;

printf("Enter the first number");
scanf("%d",&num1);
printf("Enter the second number");
scanf("%d",&num2);
