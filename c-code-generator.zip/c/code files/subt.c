#include<stdio.h>
 #include<math.h>

int main(void) {
int number1=15;

int number2=15;

int solution;

solution=number1-number2;
printf("the answer is %d", solution);
printf("stop coping and pasting stuff");
