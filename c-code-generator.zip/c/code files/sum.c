#include<stdio.h>
 #include<math.h>

int main(void) {
int num1;

int num2;

printf("enter the first value");
scanf("%d",&num1);
scanf("%d",&num1);
printf("enter the second value");
scanf("%d",&num2);

int sum;

sum=num1+num2;
printf("the sum of the two numbers is %d", sum);
