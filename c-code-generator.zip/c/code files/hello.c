#include <stdio.h>
#include <math.h>


int main(void) {
int num1;

int number;

float date;

printf("Hello \n new world");}
