#include<stdio.h>
#include<math.h>

int main(void) {
int number;

printf("Enter the number to tes");
scanf("%d",&number);if(number%2==0){
printf("The number %d you entered is even", number);}else {
printf("The number %d you entered is odd", number); 
}}
