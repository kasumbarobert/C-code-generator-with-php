#include <stdio.h>
#include <math.h>


int main(void) {
int radius;

float area;

float area;

printf("Enter the radius of the circle ");
scanf("%d",&radius);
area=PI*radius*radius;
printf("The area of the circle is %f", area);
