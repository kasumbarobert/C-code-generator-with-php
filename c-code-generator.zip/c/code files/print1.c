#include<stdio.h>
 #include<math.h>

int main(void) {
int a;

printf("enter the value of a");
