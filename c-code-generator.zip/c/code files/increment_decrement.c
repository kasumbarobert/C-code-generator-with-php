#include <stdio.h>
#include <math.h>


int main(void) {
int number1=8;

float number2=4.56;
if(number1>=number2){
number1=number1-2;}else {
number1=number1+2; 
}
printf("The original value of number1 was 8 \n , number2 was 4.56 and the current value is %d", number1);}
