#include<stdio.h>
 #include<math.h>

int main(void) {
printf("hello world!");
int a=2;

