/*Factorials*/
#include <stdio.h>
#include <math.h>


int fact (int  ) ;

int fact2 (int n ) ;

int main(void) {
int n;

printf("Enter the no whose factorial is required : ");
scanf("%d",&n);
int facto;

facto = fact2(n);
printf("\nFactorial of %d is %d\n", n, facto);}

int fact (int  ) {
}
int fact2 (int n ) {
}