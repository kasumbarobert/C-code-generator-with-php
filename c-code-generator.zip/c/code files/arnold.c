#include<stdio.h>
 #include<math.h>

int main(void) {
int x=1;

int y=5;

int p;
if(x>=y){}else if (x>=y) {
p=x-y;
printf("answer is %d", p);}else {
p=y-x;
printf("answer is %d otherwise", p); 
}}
