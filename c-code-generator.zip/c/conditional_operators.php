<p id='operators'>
<input type='button' value='*' onClick='updateExp("*");' />
<input type='button' value='+'  onClick='updateExp("+");' />
<input type='button' value='/'  onClick='updateExp("/");'/> 
<input type='button' value='-'  onClick='updateExp("-");'/>
<input type='button' value='%'  onClick='updateExp("%");'/>  
<input type='button' value='>'  onClick='updateExp(">");'/>
<input type='button' value='<'  onClick='updateExp("<");'/>
<input type='button' value='='  onClick='updateExp("=");'/>
<input type='button' value='==' onClick='updateExp("==");'/>
<input type='button' value='>=' onClick='updateExp(">=");'/>
<input type='button' value='<=' onClick='updateExp("<=");'/>
<input type='button' value='!=' onClick='updateExp("!=");'/> 
<input type='button' value='('  onClick='updateExp("(");'/> 
<input type='button' value=')'  onClick='updateExp(")");'/> 
</p>