<script>
var keywords = new array('int','char','break','if','auto','double','struct','else','long','switch','case','enum',
	'register','typedef','extern','return','union','const','float','short','unsigned','continue','for','signed',
	'void','default','goto','sizeof','volatile','do','static','while','_Bool','_Complex','_Imaginary','inline',
	'restrict','string');
</script>